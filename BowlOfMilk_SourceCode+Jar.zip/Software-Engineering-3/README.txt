Instructions for running code:

Through an IDE, preferably eclipse or intellij
For best display go for 1 human player and 1 AI
Certain features such as trade are human-to-human interactions only
