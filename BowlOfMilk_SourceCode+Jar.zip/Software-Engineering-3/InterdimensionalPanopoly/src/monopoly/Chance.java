package monopoly;

public class Chance extends NamedLocation
{
	public Chance() 
	{
		super("Chance");
	}
}
