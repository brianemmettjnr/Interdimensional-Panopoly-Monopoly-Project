package interfaces;

public interface Rollable {
	public int rollDice(int numDice, int numSides);
}
