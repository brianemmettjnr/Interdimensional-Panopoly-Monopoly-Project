package interfaces;

public interface Locatable extends Identifiable
{
	public int getPosition();
}
