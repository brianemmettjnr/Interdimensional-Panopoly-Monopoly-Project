package interfaces;

public interface Taxable {

	public int getFlatAmount();
}
