package monopoly;

public class CommunityChest extends NamedLocation
{
	public CommunityChest() 
	{
		super("Community Chest");
	}
}
