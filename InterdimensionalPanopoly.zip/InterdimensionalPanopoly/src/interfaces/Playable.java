package interfaces;

public interface Playable extends Identifiable {
	
	public int getBalance();
	public int getNetWorth();
}
