package interfaces;

public interface Identifiable {
	public String getIdentifier();
}
