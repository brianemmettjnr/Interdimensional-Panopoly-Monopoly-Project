package interfaces;

import monopoly.Panopoly;

public interface Cardable 
{
	public String getCard(Panopoly panopoly);
}
