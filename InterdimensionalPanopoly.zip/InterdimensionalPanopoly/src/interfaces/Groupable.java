package interfaces;

import monopoly.Group;

public interface Groupable extends Identifiable
{
	public Group getGroup();
}
