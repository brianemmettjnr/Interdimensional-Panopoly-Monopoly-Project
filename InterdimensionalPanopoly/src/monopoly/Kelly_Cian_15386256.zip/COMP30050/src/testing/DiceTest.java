package testing;
import static org.junit.Assert.*;
import org.junit.Test;
import monopoly.Dice;

public class DiceTest 
{
		
	@Test(timeout=1000)
	
	public void evaluate()
	{
		int sum12 = 0;
		int sum11 = 0;
		int sum10 = 0;
		int sum9 = 0;
		int sum8 = 0;
		int sum7 = 0;
		int sum6 = 0;
		int sum5 = 0;
		int sum4 = 0;
		int sum3 = 0;
		int sum2 = 0;
		
		Dice dice = new Dice();
		
		for(int i = 0; i < 10000; i++) //rolls dice 10000 times & divide by 10 to eliminate outliers
		{
			int rand1 = dice.rollDice(2,6);

			if(rand1 == 12)
			{
				sum12 += 12;	
			}
			if(rand1 == 11)
			{
				sum11 += 11;
			}
			if(rand1 == 10)
			{
				sum10 += 10;
			}
			if(rand1 == 9)
			{
				sum9 += 9;
			}
			if(rand1 == 8)
			{
				sum8 += 8;
			}
			if(rand1 == 7)
			{
				sum7 += 7;
			}
			if(rand1 == 6)
			{
				sum6 += 6;
			}
			if(rand1 == 5)
			{
				sum5 += 5;
			}
			if(rand1 == 4)
			{
				sum4 += 4;
			}
			if(rand1 == 3)
			{
				sum3 += 3;
			}
			if(rand1 == 2)
			{
				sum2 += 2;
			}
		}
		assertEquals(276,((sum12/10)/27.8),120); // since 3rd must be positive(120) take odds of occurring =(2.78) - (0.5) allowance = 276 and make 120 be tolerance of 1.0 percent
		assertEquals(561,((sum11/10)/55.6),110); // all the others follow this pattern
		assertEquals(780,((sum10/10)/83.3),100); // 83.3 since 10 should come up roughly 83.3 times in 100 2 dice rolls
		assertEquals(954,((sum9/10)/111.1),90);
		assertEquals(1072,((sum8/10)/138.9),80);
		assertEquals(1134,((sum7/10)/166.7),70);
		assertEquals(804,((sum6/10)/138.9),60);
		assertEquals(530,((sum5/10)/111.1),50);
		assertEquals(316,((sum4/10)/83.3),32);
		assertEquals(153,((sum3/10)/55.6),30);
		assertEquals(46,((sum2/10)/27.8),20);
	}
}

//Cian Kelly 15386256
