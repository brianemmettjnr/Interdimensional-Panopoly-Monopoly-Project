package testing;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import testing.DiceTest;
import testing.EquallyLikelyDiceTest;



@RunWith(Suite.class)
@SuiteClasses
		({
			DiceTest.class,
			EquallyLikelyDiceTest.class
		})
public class BatteryOfTests {} // unable to find classes?

//Cian Kelly 15386256