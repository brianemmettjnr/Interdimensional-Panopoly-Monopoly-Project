package monopoly;

public interface Taxable 
{
	public double getIncomePercentage();
	public double getFlatAmount();
}
