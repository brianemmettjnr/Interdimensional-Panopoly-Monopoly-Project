/*package monopoly;

public class Board 
{
	class Square
	{
		int num1;
		int num2;
		String s1;
		String s2;
	}

	Square[] s = new Square[10];

	Board()
	{
		s[0] = new NamedLocation();
		s[1] = new InvestmentProperty(100, 150, 1, 0, null, null);
		s[2] = new NamedLocation();
		s[3] = new InvestmentProperty(120, 125, 0, 0, null, null);
		s[4] = new TaxableProperty(null);
		s[5] = new RentalProperty(250, 270, null, null);
		s[6] = new InvestmentProperty(150, 210, 2, 0, null, null);
		s[7] = new NamedLocation(null);
		s[8] = new InvestmentProperty(200, 1000, 0, 1, null, null); // type mismatch
	}
}*/