package monopoly;

public class RentalProperty extends PrivateProperty implements Rentable, Mortgageable 
{
	
	private boolean mortgaged;
	private int mortgageValue;
	private int rentAmount;
	
	RentalProperty(Playable owner, Locatable getLeft, Locatable getRight, String PropName, int mortgageValue, int rentAmount)
	{
		super(getLeft, getRight, PropName, owner);
		this.mortgageValue = mortgageValue;
		this.rentAmount = rentAmount;
		mortgaged = false;
	}

	
	public int getMortgageAmount() 
	{
		if(mortgaged == false)
		{
			return mortgageValue;
		}
		else
		return 0;
	}

	
	public double getRentalAmount() 
	{
		return rentAmount;
	}

}
