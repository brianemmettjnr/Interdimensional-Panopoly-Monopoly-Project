package monopoly;

public interface Ownable 
{
	public Playable getOwner();
}
