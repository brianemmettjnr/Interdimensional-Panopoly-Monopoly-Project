package monopoly;

public interface Identifiable 
{
	public String getIdentifier();
}
