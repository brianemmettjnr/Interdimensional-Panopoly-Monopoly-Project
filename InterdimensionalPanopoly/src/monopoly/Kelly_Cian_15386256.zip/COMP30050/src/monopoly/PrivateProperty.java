package monopoly;

public class PrivateProperty extends NamedLocation implements Ownable
{

	private Playable owner;

	PrivateProperty(Locatable getLeft, Locatable getRight, String PropName, Playable owner)
	{
		super(getRight, getLeft, PropName); 
		this.owner = owner;
	}

	public Playable getOwner() 
	{
		return owner;
	}
	
}
