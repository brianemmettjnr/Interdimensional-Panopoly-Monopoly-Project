package monopoly;

public class Main 
{
	public class Playable
	{
		public Playable(String string) 
		{
		}

		private String name;
	}
	
	// tried to create Locatable and Playable, however they have been implemented and left as null values
	
	//static monopoly.Playable owner = new Playable("James");
	//Playable owner1 = new Playable("Jimmy");
	//Playable owner2 = new Playable("Shannon");
	//Playable owner3 = new Playable("Mary");
	
	static NamedLocation namedlocation = new NamedLocation(null, null, "St.James Gate");
	static NamedLocation namedlocation1 = new NamedLocation(null, namedlocation, "Phoenix Park");
	static NamedLocation namedlocation2 = new NamedLocation(null, namedlocation1, "Marley Park");
	static NamedLocation namedlocation3 = new NamedLocation(null, namedlocation2, "Croke Park");
	static NamedLocation namedlocation4 = new NamedLocation(null, namedlocation3, "Grafton Street");
	
	
	static PrivateProperty privateproperty = new PrivateProperty(namedlocation, namedlocation4, "St.James Gate", null);
	static PrivateProperty privateproperty1 = new PrivateProperty(namedlocation1, namedlocation, "Phoenix Park", null);
	static PrivateProperty privateproperty2 = new PrivateProperty(namedlocation2, namedlocation1, "Marley Park", null);
	static PrivateProperty privateproperty3 = new PrivateProperty(namedlocation3, namedlocation2, "Croke Park", null);
	static PrivateProperty privateproperty4 = new PrivateProperty(namedlocation4, namedlocation3, "Grafton Streer", null);

	
	static RentalProperty rentalproperty = new RentalProperty(null, privateproperty, privateproperty, "St.James Gate", 150, 200);
	static RentalProperty rentalproperty1 = new RentalProperty(null, privateproperty1, privateproperty1, "Phoenix Park", 200, 250);
	static RentalProperty rentalproperty2 = new RentalProperty(null, privateproperty2, namedlocation2, "Marley Park", 250, 300);
	static RentalProperty rentalproperty3 = new RentalProperty(null, privateproperty3, namedlocation3, "Croke Park", 300, 350);
	static RentalProperty rentalproperty4 = new RentalProperty(null, privateproperty4, namedlocation4, "Grafton Street", 350, 400);

	
	static InvestmentProperty investmentproperty = new InvestmentProperty(150, 500, null, rentalproperty, rentalproperty, "St.James Gate", 2, 0);
	static InvestmentProperty investmentproperty1 = new InvestmentProperty(200, 250, null, rentalproperty1, rentalproperty1, "Phoenix Park", 0, 0);
	static InvestmentProperty investmentproperty2 = new InvestmentProperty(250, 1300, null, rentalproperty2, rentalproperty2, "Marley Park", 0, 1);
	static InvestmentProperty investmentproperty3 = new InvestmentProperty(300, 900, null, rentalproperty3, rentalproperty3, "Croke Park", 4, 0);
	static InvestmentProperty investmentproperty4 = new InvestmentProperty(350, 400, null, rentalproperty4, rentalproperty4, "Grafton Street", 0, 0);

	
	static TaxableProperty taxableproperty = new TaxableProperty(namedlocation1, namedlocation4, "St.James Gate" );
	static TaxableProperty taxableproperty1 = new TaxableProperty(namedlocation2, namedlocation, "Phoenix Park");
	static TaxableProperty taxableproperty2 = new TaxableProperty(namedlocation3, namedlocation1, "Marley Park");
	static TaxableProperty taxableproperty3 = new TaxableProperty(namedlocation4, namedlocation2, "Croke Park");
	static TaxableProperty taxableproperty4 = new TaxableProperty(namedlocation, namedlocation3, "Gafton Street");
	
	
 public static void main(String [] args)
			{
				
				System.out.println(taxableproperty.getFlatAmount());  // prints out string as test to ensure working
				System.out.println(taxableproperty.getIncomePercentage());
				
				System.out.println(investmentproperty.getNumHotels());
				System.out.println(investmentproperty.getNumHouses());

				System.out.println(rentalproperty.getMortgageAmount());
				System.out.println(rentalproperty.getRentalAmount());
				
				System.out.println(privateproperty.getOwner());
				
				System.out.println(namedlocation.goLeft());
				System.out.println(namedlocation.goRight());
				System.out.println(taxableproperty.getIdentifier()); // shows that extension of classes works as taxableproperty get method from namedlocation
				
				return;
			}
}

