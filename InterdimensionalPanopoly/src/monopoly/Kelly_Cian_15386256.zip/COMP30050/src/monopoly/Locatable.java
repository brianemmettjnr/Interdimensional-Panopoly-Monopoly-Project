package monopoly;

public interface Locatable extends Identifiable
{
	public Locatable goLeft();
	public Locatable goRight();
	
}
// come back to