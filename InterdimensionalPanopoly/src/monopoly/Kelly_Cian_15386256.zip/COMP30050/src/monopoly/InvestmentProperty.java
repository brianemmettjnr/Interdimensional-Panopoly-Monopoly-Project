package monopoly;

public class InvestmentProperty extends RentalProperty implements Improvable
{
	private int numHouses;
	private int numHotels;
	
	InvestmentProperty(int mortgageValue, int rentAmount, Playable owner, Locatable getLeft, Locatable getRight, String PropName, int numHouses, int numHotels) 
	{
		super(owner, getLeft, getRight, PropName, rentAmount, mortgageValue); // gets input from its extensions
		this.numHotels = numHotels; 
		this.numHouses = numHouses;
	}

	@Override
	public int getNumHouses() 
	{
		return numHouses;
	}

	@Override
	public int getNumHotels()
	{
		return numHotels;
	}

}
