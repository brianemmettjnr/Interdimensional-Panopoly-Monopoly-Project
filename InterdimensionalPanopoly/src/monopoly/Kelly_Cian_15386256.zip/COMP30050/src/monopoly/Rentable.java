package monopoly;

public interface Rentable extends Ownable
{
	public double getRentalAmount();
}
