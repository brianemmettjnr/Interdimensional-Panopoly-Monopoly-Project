package monopoly;

public interface Improvable extends Ownable
{
	public int getNumHouses();
	public int getNumHotels();
}
