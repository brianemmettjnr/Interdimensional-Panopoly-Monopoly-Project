package monopoly;

public class TaxableProperty extends NamedLocation implements Taxable
{

	private final static int taxPerct = 15;  
	private final static int flatAmount = 200;  
	
	
	TaxableProperty(Locatable getLeft, Locatable getRight, String PropName) 
	{
		super(getLeft, getRight, PropName);
	}
	
	@Override
	public double getIncomePercentage()
	{
		return taxPerct;
	}

	@Override
	public double getFlatAmount()
	{
		return flatAmount;
	}
	
}
