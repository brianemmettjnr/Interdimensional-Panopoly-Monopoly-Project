package monopoly;

public  class Player
{
	
	private Playable owner;


}
