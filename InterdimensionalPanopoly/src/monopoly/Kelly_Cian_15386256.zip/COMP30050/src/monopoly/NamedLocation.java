package monopoly;

public class NamedLocation implements Locatable, Identifiable
{
	private Locatable getLeft;
	private Locatable getRight;
	private String PropName;

	NamedLocation(Locatable getLeft, Locatable getRight, String PropName)
	{
		this.getLeft = getLeft;
		this.getRight = getRight;
		this.PropName = PropName;
	}
	
	public Locatable goLeft() 
	{
		return getLeft; // +1 set as array 
	}

	
	public Locatable goRight() 
	{
		return getRight; //-1 set as array
	}

	
	public String getIdentifier() 
	{ 
		return PropName;
	}


}
