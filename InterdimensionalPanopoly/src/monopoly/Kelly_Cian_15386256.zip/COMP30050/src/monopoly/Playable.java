package monopoly;

public class Playable 
{
	String owner;
	
	public String owner() 
	{
		return owner;
	}
	
}// should convert datatype playable to string
