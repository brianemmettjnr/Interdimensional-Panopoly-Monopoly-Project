package monopoly;

public interface Mortgageable extends Ownable
{
	public int getMortgageAmount();
}

// put setters in his interfaces